//space
background(0, 0, 0);
ellipse(100, 200, 10, 10);
ellipse(50, 85, 12, 12);
ellipse(300, 200, 9, 9);
ellipse(200, 50, 10, 10);

//shot
fill(0, 255, 0);
ellipse(190, 165, 60, 10);

//robotmale
image(getImage("jun.png"), 250, 275);

//planet
image(getImage("jun.png"), 200, 100);

//ship
image(getImage("jun.png"), 0, 100, 100, 100);
image(getImage("jun.png"), 0, 100, 80, 80);